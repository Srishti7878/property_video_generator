"""
Assemble a short promotional property video.

Look (matches a typical real-estate promo reel):
  * every photo fills the 16:9 frame - portrait / odd-sized photos get a blurred,
    darkened copy of themselves as background instead of black bars
  * title overlay on the first photo (name, "Type | Location", price) with gold accent
  * feature photos with a translucent caption bar + gold accent line
  * slow Ken-Burns zoom and cross-fades between scenes
  * closing call-to-action in gold over the last photo
  * optional voice-over + background music

Frames are drawn with Pillow/numpy and piped to ffmpeg, so there is no drawtext /
font dependency and it behaves the same on Windows, macOS and Linux.
"""

import os
import platform
import subprocess
import tempfile
from typing import Dict, List

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H, FPS = 1280, 720, 30
GOLD = (233, 186, 84)
WHITE = (255, 255, 255)
BAR = (12, 12, 14)
XFADE = 0.7          # cross-fade seconds
ZOOM = 0.06          # total Ken-Burns zoom over one scene


# --------------------------------------------------------------------------- fonts
def _get_font(size: int, bold: bool = True):
    if platform.system() == "Windows":
        names = ["arialbd.ttf", "segoeuib.ttf", "calibrib.ttf"] if bold else ["arial.ttf", "segoeui.ttf"]
        candidates = [f"C:/Windows/Fonts/{n}" for n in names]
    elif platform.system() == "Darwin":
        candidates = ["/System/Library/Fonts/Supplemental/Arial Bold.ttf",
                      "/System/Library/Fonts/Supplemental/Arial.ttf"]
    else:
        candidates = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold
                      else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                      "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    for p in candidates:
        if os.path.isfile(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


def _wrap(draw, text, font, max_w):
    lines, cur = [], ""
    for w in text.split():
        t = f"{cur} {w}".strip()
        if draw.textlength(t, font=font) <= max_w:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [""]


# ------------------------------------------------------------------ photo -> canvas
def _fit_photo(path: str, scale: float = 1.0) -> Image.Image:
    """Photo fitted to full height on a blurred, darkened copy of itself."""
    img = Image.open(path).convert("RGB")
    cw, ch = int(W * scale), int(H * scale)

    # blurred cover background
    k = max(cw / img.width, ch / img.height)
    bg = img.resize((int(img.width * k) + 1, int(img.height * k) + 1), Image.Resampling.BILINEAR)
    bx, by = (bg.width - cw) // 2, (bg.height - ch) // 2
    bg = bg.crop((bx, by, bx + cw, by + ch)).filter(ImageFilter.GaussianBlur(28 * scale))
    bg = Image.eval(bg, lambda v: int(v * 0.55))

    # foreground: contain
    k = min(cw / img.width, ch / img.height)
    fg = img.resize((max(1, int(img.width * k)), max(1, int(img.height * k))), Image.Resampling.LANCZOS)
    bg.paste(fg, ((cw - fg.width) // 2, (ch - fg.height) // 2))
    return bg


# ------------------------------------------------------------------------ overlays
def _overlay_layer(kind: str, text: str = "", sub: str = "", price: str = "") -> Image.Image:
    """RGBA layer (WxH) with the text bar for a scene."""
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    if kind == "title":
        f_title, f_sub, f_price = _get_font(52), _get_font(22, False), _get_font(26)
        t_lines = _wrap(d, text, f_title, W - 160)
        bar_h = 40 + len(t_lines) * 64 + (34 if sub else 0) + (44 if price else 0) + 20
        y0 = H - bar_h
        d.rectangle([0, y0, W, H], fill=BAR + (215,))
        y = y0 + 22
        d.rectangle([W // 2 - 40, y, W // 2 + 40, y + 3], fill=GOLD + (255,))
        y += 16
        for ln in t_lines:
            d.text((W // 2, y), ln, font=f_title, fill=WHITE + (255,), anchor="ma")
            y += 64
        if sub:
            d.text((W // 2, y), sub, font=f_sub, fill=(225, 225, 225, 255), anchor="ma")
            y += 38
        if price:
            d.text((W // 2, y), price, font=f_price, fill=GOLD + (255,), anchor="ma")

    elif kind == "caption":
        font = _get_font(32)
        lines = _wrap(d, text, font, W - 140)
        bar_h = 28 + len(lines) * 42
        y0 = H - bar_h
        d.rectangle([0, y0, W, H], fill=BAR + (205,))
        d.rectangle([0, y0, W, y0 + 3], fill=GOLD + (255,))
        y = y0 + 16
        for ln in lines:
            d.text((W // 2, y), ln, font=font, fill=WHITE + (255,), anchor="ma")
            y += 42

    elif kind == "cta":
        font = _get_font(38)
        lines = []
        for part in [p.strip() for p in text.replace(". ", ".\n").split("\n") if p.strip()]:
            lines += _wrap(d, part, font, W - 140)
        bar_h = 30 + len(lines) * 50
        y0 = H - bar_h
        d.rectangle([0, y0, W, H], fill=BAR + (215,))
        d.rectangle([0, y0, W, y0 + 3], fill=GOLD + (255,))
        y = y0 + 20
        for ln in lines:
            d.text((W // 2, y), ln, font=font, fill=GOLD + (255,), anchor="ma")
            y += 50
    return layer


# --------------------------------------------------------------------------- audio
def _create_ambient_audio(duration: float = 30.0) -> str:
    """Soft warm pad (A-minor-ish chord with slow tremolo) - no files needed."""
    tmp = tempfile.NamedTemporaryFile(suffix=".m4a", delete=False)
    tmp.close()
    d = f"{duration:.2f}"
    notes = [110.0, 164.81, 220.0, 261.63, 329.63]
    ins, mix = [], []
    for i, f in enumerate(notes):
        ins += ["-f", "lavfi", "-i", f"sine=frequency={f}:duration={d}"]
        mix.append(f"[{i}:a]tremolo=f={0.15 + i * 0.07:.2f}:d=0.5,volume={0.20 if i < 2 else 0.12}[n{i}]")
    chain = ";".join(mix) + ";" + "".join(f"[n{i}]" for i in range(len(notes))) + \
        f"amix=inputs={len(notes)}:normalize=0,lowpass=f=1400,aecho=0.8:0.6:600:0.3," \
        f"afade=t=in:d=2,afade=t=out:st={max(0, duration - 2.5):.2f}:d=2.5[a]"
    cmd = ["ffmpeg", "-y", *ins, "-filter_complex", chain, "-map", "[a]",
           "-c:a", "aac", "-b:a", "128k", tmp.name]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-400:])
    return tmp.name


def _audio_duration(path: str) -> float:
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=nw=1:nk=1", path], capture_output=True, text=True)
        return float(r.stdout.strip())
    except Exception:
        return 0.0


# ---------------------------------------------------------------------------- main
def generate_video(
    property_data: Dict,
    script: Dict,
    image_paths: List[str],
    output_path: str = "output/property_video.mp4",
    duration_per_image: float = 4.2,
    background_music: str = None,
    voiceover_path: str = None,
) -> str:
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    valid = []
    for p in image_paths:
        if os.path.isfile(p):
            valid.append(p)
        else:
            print(f"Warning: image not found -> {p}")
    if not valid:
        raise ValueError("No valid images provided. Please supply at least one existing image path.\n"
                         "Example: sample_data/img1.jpg")
    valid = valid[:8]

    # ---- scene plan: title (photo 1) -> one photo per feature -> CTA (last photo)
    captions = [s["caption"] for s in script["scenes"]]
    n_feat = len(captions)
    feat_imgs = valid[1:1 + n_feat] if len(valid) > 1 else valid
    if len(feat_imgs) < n_feat:                      # fewer photos than features: cycle
        feat_imgs = [valid[(1 + i) % len(valid)] for i in range(n_feat)]
    cta_img = valid[-1] if len(valid) > n_feat + 1 else valid[0]

    sub = " | ".join(x for x in [str(property_data.get("type", "")).strip(),
                                 str(property_data.get("location", "")).strip()] if x)
    name = str(property_data.get("name", "")).strip() or script["title"]
    price = str(property_data.get("price", "")).strip()

    scenes = [dict(img=valid[0], kind="title", text=name, sub=sub, price=price, dur=4.2)]
    for img, cap in zip(feat_imgs, captions):
        scenes.append(dict(img=img, kind="caption", text=cap, dur=duration_per_image))
    scenes.append(dict(img=cta_img, kind="cta", text=script["cta"], dur=3.8))

    # stretch to cover the voice-over, if any
    has_voice = bool(voiceover_path and os.path.isfile(voiceover_path))
    total = sum(s["dur"] for s in scenes) - XFADE * (len(scenes) - 1)
    if has_voice:
        need = _audio_duration(voiceover_path) + 1.2
        if need > total:
            k = (need - total) / sum(s["dur"] for s in scenes) + 1
            for s in scenes:
                s["dur"] *= k
            total = sum(s["dur"] for s in scenes) - XFADE * (len(scenes) - 1)

    # ---- pre-render scene bases (slightly oversized so the zoom has room)
    for s in scenes:
        s["base"] = _fit_photo(s["img"], 1.0 + ZOOM)
        s["layer"] = _overlay_layer(s["kind"], s["text"], s.get("sub", ""), s.get("price", ""))

    def scene_frame(s, t):
        p = min(1.0, max(0.0, t / s["dur"]))
        z = 1.0 + ZOOM * (1 - p) if s["kind"] == "cta" else 1.0 + ZOOM * p   # CTA eases back out
        base = s["base"]
        cw, ch = base.width / z, base.height / z
        x0, y0 = (base.width - cw) / 2, (base.height - ch) / 2
        fr = base.resize((W, H), Image.Resampling.BILINEAR, box=(x0, y0, x0 + cw, y0 + ch)).convert("RGBA")
        # text fades in over the first 0.5s
        a = min(1.0, t / 0.5)
        layer = s["layer"]
        if a < 1.0:
            layer = layer.copy()
            layer.putalpha(layer.getchannel("A").point(lambda v: int(v * a)))
        fr.alpha_composite(layer)
        return np.asarray(fr.convert("RGB"), dtype=np.float32)

    n_frames = int(round(total * FPS))
    starts, acc = [], 0.0
    for s in scenes:
        starts.append(acc)
        acc += s["dur"] - XFADE

    silent = output_path + ".video.mp4"
    enc = subprocess.Popen(
        ["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
         "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
         "-movflags", "+faststart", silent],
        stdin=subprocess.PIPE, stderr=subprocess.PIPE)

    temp_files = []
    try:
        print(f"Rendering {n_frames} frames ({total:.1f}s)...")
        try:
            for fi in range(n_frames):
                T = fi / FPS
                live = [i for i, s in enumerate(scenes) if starts[i] <= T < starts[i] + s["dur"]]
                if not live:
                    live = [len(scenes) - 1]
                i = live[-1]
                f = scene_frame(scenes[i], T - starts[i])
                if len(live) > 1:                           # cross-fade with previous scene
                    j = live[0]
                    k = (T - starts[i]) / XFADE
                    f = scene_frame(scenes[j], T - starts[j]) * (1 - k) + f * k
                # fade in from black at the very start / out at the very end
                edge = min(1.0, T / 0.5, (total - T) / 0.7)
                if edge < 1.0:
                    f = f * max(0.0, edge)
                enc.stdin.write(np.clip(f, 0, 255).astype(np.uint8).tobytes())
        finally:
            enc.stdin.close()
        err = enc.stderr.read().decode(errors="ignore")
        if enc.wait() != 0:
            print(err[-600:])
            raise RuntimeError("ffmpeg failed while encoding. Make sure ffmpeg is installed and in your PATH.")
        temp_files.append(silent)

        # ---- audio
        has_music = bool(background_music and os.path.isfile(background_music))
        if not has_music:
            try:
                print("Creating soft background music...")
                background_music = _create_ambient_audio(total + 1)
                temp_files.append(background_music)
                has_music = True
            except Exception as e:
                print(f"Could not create background music: {e}")

        fade_out = f"afade=t=out:st={max(0, total - 2):.2f}:d=2"
        cmd = ["ffmpeg", "-y", "-i", silent]
        if has_voice and has_music:
            print("Adding voice-over + background music...")
            cmd += ["-i", voiceover_path, "-stream_loop", "-1", "-i", background_music,
                    "-filter_complex",
                    "[1:a]adelay=600|600,volume=1.0[v];"
                    f"[2:a]volume=0.22,afade=t=in:d=1.5[m];"
                    f"[v][m]amix=inputs=2:duration=longest:normalize=0,{fade_out}[a]",
                    "-map", "0:v", "-map", "[a]"]
        elif has_voice:
            cmd += ["-i", voiceover_path, "-af", f"adelay=600|600,{fade_out}", "-map", "0:v", "-map", "1:a"]
        elif has_music:
            print("Adding background music...")
            cmd += ["-stream_loop", "-1", "-i", background_music,
                    "-af", f"volume=0.5,afade=t=in:d=1.5,{fade_out}", "-map", "0:v", "-map", "1:a"]
        else:
            os.replace(silent, output_path)
            print(f"\nVideo successfully saved to: {output_path}")
            return output_path
        cmd += ["-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-t", f"{total:.2f}", output_path]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            print("Warning: could not add audio, saving silent video.")
            print(r.stderr[-400:])
            os.replace(silent, output_path)

        print(f"\nVideo successfully saved to: {output_path}")
        return output_path
    finally:
        for f in temp_files:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except Exception:
                pass
