"""Draws the six illustrated demo 'photos' used by the sample property.
Replace sample_data/img*.jpg with real photos for real use."""
import random, math
from PIL import Image, ImageDraw, ImageFilter
import os
OUT = os.path.dirname(os.path.abspath(__file__))
random.seed(7)

def vgrad(w, h, top, bot):
    im = Image.new("RGB", (w, h)); d = ImageDraw.Draw(im)
    for y in range(h):
        t = y / (h - 1)
        d.line([(0, y), (w, y)], fill=tuple(int(top[i] + (bot[i]-top[i])*t) for i in range(3)))
    return im

def glow(im, xy, r, color, alpha=120):
    ov = Image.new("RGBA", im.size, (0,0,0,0)); d = ImageDraw.Draw(ov)
    d.ellipse([xy[0]-r, xy[1]-r, xy[0]+r, xy[1]+r], fill=color+(alpha,))
    ov = ov.filter(ImageFilter.GaussianBlur(r/2))
    im.paste(ov, (0,0), ov)

def finish(im, name):
    vig = Image.new("L", im.size, 0); d = ImageDraw.Draw(vig)
    w, h = im.size
    d.ellipse([-w*.25, -h*.25, w*1.25, h*1.25], fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(min(w,h)//5))
    dark = Image.new("RGB", im.size, (10,10,14))
    im = Image.composite(im, dark, vig.point(lambda v: 120 + v*135//255))
    im.save(os.path.join(OUT, name), quality=92)

def palm(d, x, y, h, lean=0):
    d.line([(x, y), (x+lean, y-h)], fill=(70,50,35), width=max(4,h//30))
    tx, ty = x+lean, y-h
    for a in range(-80, 260, 40):
        ex = tx + math.cos(math.radians(a))*h*.45
        ey = ty + math.sin(math.radians(a))*h*.25 + h*.08
        d.line([(tx,ty),((tx+ex)/2, min(ty,ey)-h*.08),(ex,ey)], fill=(34,100,52), width=max(3,h//40))

def villa():
    W,H = 1600,900
    im = vgrad(W,H,(255,170,110),(250,214,170)); d = ImageDraw.Draw(im)
    glow(im,(1180,430),260,(255,230,170),150); d = ImageDraw.Draw(im)
    d.polygon([(0,560),(300,470),(620,540),(980,450),(1300,530),(1600,470),(1600,H),(0,H)], fill=(140,120,130))
    d.rectangle([0,600,W,H], fill=(70,130,70))
    d.polygon([(560,H),(1040,H),(900,640),(700,640)], fill=(195,180,165))      # driveway
    # villa body
    d.rectangle([330,380,1270,640], fill=(240,232,218))
    d.rectangle([330,380,1270,396], fill=(205,195,180))
    d.polygon([(300,380),(800,250),(1300,380)], fill=(150,75,55))              # roof
    d.rectangle([760,330,840,380], fill=(150,75,55))
    d.rectangle([880,470,1230,640], fill=(228,218,200))
    d.rectangle([330,440,620,640], fill=(228,218,200))
    for x0,x1,y0,y1 in [(360,450,470,570),(480,570,470,570),(910,1000,480,590),(1030,1120,480,590),(1140,1210,480,590)]:
        d.rectangle([x0,y0,x1,y1], fill=(255,214,130)); d.rectangle([x0,y0,x1,y1], outline=(90,70,60), width=5)
        d.line([((x0+x1)//2,y0),((x0+x1)//2,y1)], fill=(90,70,60), width=3)
    d.rectangle([690,500,910,640], fill=(95,60,45)); d.rectangle([780,500,820,640], fill=(70,45,35))
    d.rectangle([640,640,960,660], fill=(210,200,185))
    for x in range(330, 1280, 40): d.rectangle([x,640,x+22,650], fill=(60,110,60))
    for x,h,l in [(200,380,30),(1420,430,-30),(120,300,20)]: palm(d,x,650,h,l)
    for x in range(0,W,26):                                                     # hedge
        d.ellipse([x-18,625,x+22,665], fill=(40,105,55))
    finish(im,"img1.jpg")

def living():
    W,H = 1600,900
    im = Image.new("RGB",(W,H),(226,214,198)); d = ImageDraw.Draw(im)
    d.rectangle([0,650,W,H], fill=(150,112,80))
    for x in range(-400,W+400,110): d.line([(x,650),(x-(W/2-x)*.35,H)], fill=(130,95,66), width=3)
    win = vgrad(560,420,(255,200,140),(150,190,230)); im.paste(win,(980,150))
    d = ImageDraw.Draw(im)
    for i in range(7):
        bx = 1000+i*75; bh = random.randint(60,190); d.rectangle([bx,570-bh,bx+55,570], fill=(110,120,150))
    d.rectangle([980,150,1540,570], outline=(70,55,45), width=10); d.line([(1260,150),(1260,570)], fill=(70,55,45), width=6)
    d.polygon([(940,130),(980,130),(980,640),(900,640)], fill=(200,160,110))
    d.polygon([(1540,130),(1600,130),(1600,640),(1560,640)], fill=(200,160,110))
    d.ellipse([120,640,860,800], fill=(236,230,222))                            # rug
    d.rounded_rectangle([90,470,760,640], 40, fill=(70,98,120))                 # sofa
    d.rounded_rectangle([90,400,760,500], 40, fill=(82,112,136))
    for x,c in [(150,(230,180,90)),(640,(220,120,90))]:
        d.rounded_rectangle([x,430,x+110,540], 20, fill=c)
    d.rounded_rectangle([300,700,640,760], 12, fill=(70,52,40))                 # table
    d.rectangle([310,760,330,800], fill=(50,38,30)); d.rectangle([610,760,630,800], fill=(50,38,30))
    d.line([(1380,640),(1380,360)], fill=(60,50,45), width=8); d.polygon([(1330,360),(1430,360),(1460,300),(1300,300)], fill=(250,225,170))
    glow(im,(1380,330),150,(255,220,150),110); d = ImageDraw.Draw(im)
    for x in (300,520,740):
        d.line([(x,0),(x,110)], fill=(60,50,45), width=3); glow(im,(x,125),70,(255,225,160),160)
        d = ImageDraw.Draw(im); d.ellipse([x-30,100,x+30,150], fill=(255,236,190))
    finish(im,"img2.jpg")

def kitchen():
    W,H = 900,1300
    im = Image.new("RGB",(W,H),(232,226,216)); d = ImageDraw.Draw(im)
    d.rectangle([0,880,W,H], fill=(205,200,195))
    for x in range(0,W,150): d.line([(x,880),(x,H)], fill=(185,180,175), width=2)
    for y in range(880,H,150): d.line([(0,y),(W,y)], fill=(185,180,175), width=2)
    d.rectangle([0,120,W,330], fill=(70,92,88))
    for x in range(40,W,200):
        d.rectangle([x,140,x+170,310], fill=(86,112,106), outline=(50,70,66), width=4); d.rectangle([x+78,205,x+92,250], fill=(210,190,140))
    d.rectangle([0,430,W,640], fill=(228,222,212))
    for y in range(430,640,35):
        for x in range(0,W,70): d.rectangle([x+(35 if (y//35)%2 else 0),y,x+68+(35 if (y//35)%2 else 0),y+33], outline=(205,198,188), width=2)
    d.rectangle([0,640,W,700], fill=(60,60,64))
    d.rectangle([0,700,W,880], fill=(70,92,88))
    for x in range(40,W,200): d.rectangle([x,720,x+170,860], outline=(50,70,66), width=4); d.rectangle([x+78,730,x+92,760], fill=(210,190,140))
    d.rectangle([300,610,600,640], fill=(25,25,28))
    for cx in (360,450,540): d.ellipse([cx-24,618,cx+24,634], fill=(90,90,96))
    d.polygon([(280,350),(620,350),(560,430),(340,430)], fill=(160,160,168))   # chimney
    d.rectangle([420,300,480,350], fill=(140,140,148))
    d.rounded_rectangle([40,930,860,1010], 8, fill=(40,38,40))                  # island
    d.rectangle([60,1010,840,1210], fill=(92,118,112))
    for x in (160,300,440): d.rectangle([x,1060,x+110,1100], fill=(56,76,72))
    for x in (160,330,500,670):
        d.ellipse([x,860,x+80,900], fill=(70,52,40)); d.line([(x+40,900),(x+40,1010)], fill=(70,52,40), width=8)
    for x in (260,450,640):
        d.line([(x,0),(x,70)], fill=(60,50,45), width=3); glow(im,(x,90),80,(255,225,160),170)
        d = ImageDraw.Draw(im); d.polygon([(x-40,110),(x+40,110),(x+20,70),(x-20,70)], fill=(30,30,34)); d.ellipse([x-18,102,x+18,122], fill=(255,236,190))
    finish(im,"img3.jpg")

def bedroom():
    W,H = 1600,900
    im = Image.new("RGB",(W,H),(210,205,215)); d = ImageDraw.Draw(im)
    d.rectangle([0,660,W,H], fill=(140,108,80))
    d.rectangle([380,120,1220,640], fill=(110,100,125))                         # feature wall
    for i in range(14):
        x = 380+i*62
        d.polygon([(x,120),(x+62,120),(x+31,640)], fill=(100+i%3*8,90+i%3*8,115+i%3*8))
    d.rounded_rectangle([420,330,1180,520], 20, fill=(150,110,90))              # headboard
    for i in range(6): d.line([(420+i*127,330),(420+i*127,520)], fill=(130,92,74), width=4)
    d.rounded_rectangle([380,500,1220,720], 30, fill=(90,150,145))
    d.rounded_rectangle([380,500,1220,560], 20, fill=(235,235,230))
    d.rectangle([380,640,1220,720], fill=(70,125,120))
    for x in (520,880): d.rounded_rectangle([x,470,x+170,540], 16, fill=(245,242,235))
    for x in (250,1330):
        d.rectangle([x-70,560,x+70,720], fill=(70,52,40)); d.line([(x,560),(x,470)], fill=(60,50,45), width=7)
        d.polygon([(x-45,470),(x+45,470),(x+30,410),(x-30,410)], fill=(250,225,170)); glow(im,(x,430),120,(255,220,150),120)
    d = ImageDraw.Draw(im)
    d.rectangle([40,100,300,620], fill=(180,210,235)); d.rectangle([40,100,300,620], outline=(80,70,65), width=8)
    d.polygon([(0,80),(120,80),(110,640),(0,640)], fill=(160,110,80)); d.polygon([(220,80),(340,80),(340,640),(230,640)], fill=(160,110,80))
    d.ellipse([480,640,1120,820], fill=(225,215,200))
    finish(im,"img4.jpg")

def pool():
    W,H = 1600,900
    im = vgrad(W,H,(90,160,230),(190,225,245)); d = ImageDraw.Draw(im)
    d.polygon([(0,380),(350,300),(700,360),(1100,290),(1600,350),(1600,430),(0,430)], fill=(110,150,150))
    d.rectangle([0,430,W,H], fill=(210,198,180))
    d.polygon([(180,520),(1420,520),(1560,860),(40,860)], fill=(60,175,205))
    for k in range(18):
        y = 540+k*17; d.line([(200-k*7,y),(1400+k*8,y)], fill=(90+k*3,200,225), width=2)
    d.polygon([(180,520),(1420,520),(1440,545),(160,545)], fill=(45,140,175))
    for x in (200,330,1270,1400):
        d.rounded_rectangle([x-70,460,x+70,495], 8, fill=(250,248,240)); d.line([(x-60,495),(x-70,520)], fill=(120,110,100), width=4)
        d.rounded_rectangle([x-60,430,x-40,470], 6, fill=(250,248,240))
    d.line([(800,380),(800,520)], fill=(90,70,50), width=6); d.pieslice([640,330,960,450],180,360, fill=(230,100,80))
    for x,h,l in [(60,330,20),(1540,360,-25),(1380,260,15)]: palm(d,x,520,h,l)
    glow(im,(1300,140),160,(255,250,220),170)
    finish(im,"img5.jpg")

def dusk():
    W,H = 900,1300
    im = vgrad(W,H,(40,50,100),(250,150,110)); d = ImageDraw.Draw(im)
    for _ in range(60): d.ellipse([(x:=random.randint(0,W)),(y:=random.randint(0,500)),x+3,y+3], fill=(255,255,235))
    d.rectangle([0,1000,W,H], fill=(35,70,60))
    d.rectangle([150,640,750,1000], fill=(225,215,200)); d.polygon([(110,640),(450,480),(790,640)], fill=(120,60,50))
    d.rectangle([130,990,770,1010], fill=(190,180,165))
    for x0,y0 in [(190,700),(330,700),(520,700),(660,700),(190,850),(330,850),(520,850),(660,850)]:
        d.rectangle([x0,y0,x0+80,y0+110], fill=(255,205,110)); d.rectangle([x0,y0,x0+80,y0+110], outline=(80,60,50), width=4)
        glow(im,(x0+40,y0+55),90,(255,200,110),70); d = ImageDraw.Draw(im)
    d.rectangle([405,880,495,1000], fill=(90,55,40))
    for x in (30,820): palm(d,x,1010,420,20 if x<400 else -20)
    for x in range(0,W,40): d.line([(x,1050),(x+20,1010),(x+40,1050)], fill=(30,90,55), width=6)
    finish(im,"img6.jpg")

for f in (villa,living,kitchen,bedroom,pool,dusk): f()
print("ok")
